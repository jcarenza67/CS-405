// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
    //FAIL();
//}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0u);

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1u);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);

    add_entries(5);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 5u);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterOrEqualToSizeForVariousEntryCounts)
{
    // For any real vector instance, max_size() should always be >= to the current size().
    EXPECT_GE(collection->max_size(), collection->size()); // 0 entries (fresh vector)

    // Add 1 item and re-check the relationship.
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size()); // 1 entry

    // Reset back to an empty vector for the next case.
    collection->clear();

    // Add 5 items and re-check.
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size()); // 5 entries

    // Reset again for the final case.
    collection->clear();

    // Add 10 items and re-check.
    add_entries(10);
    EXPECT_GE(collection->max_size(), collection->size()); // 10 entries
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterOrEqualToSizeForVariousEntryCounts)
{
    // A vector's capacity() is how many elements it can hold before reallocation.
    // capacity() should always be >= size().
    EXPECT_GE(collection->capacity(), collection->size()); // 0 entries (fresh vector)

    // Add 1 item and confirm capacity can still fit size.
    add_entries(1);
    EXPECT_GE(collection->capacity(), collection->size()); // 1 entry

    // Clear elements (capacity may stay the same; size should go to 0).
    collection->clear();

    // Add 5 items and confirm capacity still covers size.
    add_entries(5);
    EXPECT_GE(collection->capacity(), collection->size()); // 5 entries

    // Clear again for the final case.
    collection->clear();

    // Add 10 items and confirm capacity still covers size.
    add_entries(10);
    EXPECT_GE(collection->capacity(), collection->size()); // 10 entries
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesTheCollectionSize)
{
    // Start with 5 entries so we have a known baseline.
    add_entries(5);
    const auto startingSize = collection->size(); // size before resize

    // Resize larger: vector should grow to startingSize + 5.
    const auto requestedSize = startingSize + 5;
    collection->resize(requestedSize);

    // After resizing up, size must match what we requested.
    ASSERT_EQ(collection->size(), requestedSize);

    // Capacity should always be at least as large as size.
    EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesTheCollectionSize)
{
    // Arrange: fill with 10 entries.
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u); // sanity check before shrinking

    // Act: shrink down to 4 entries.
    const std::size_t requestedSize = 4;
    collection->resize(requestedSize);

    // Assert: size must now be 4.
    ASSERT_EQ(collection->size(), requestedSize);

    // Capacity should still be >= size even after shrinking.
    EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesTheCollectionSizeToZero)
{
    // Arrange: add entries so it's not empty.
    add_entries(10);
    ASSERT_FALSE(collection->empty()); // confirm precondition

    // Act: resize to 0 should remove all elements.
    collection->resize(0);

    // Assert: vector should now be empty and size should be 0.
    ASSERT_EQ(collection->size(), 0u);
    ASSERT_TRUE(collection->empty());
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesTheCollection)
{
    // Arrange: make sure there are elements to clear.
    add_entries(10);
    ASSERT_FALSE(collection->empty());

    // Act: clear removes all elements (size becomes 0).
    collection->clear();

    // Assert: vector is empty and size is 0.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginToEndErasesTheCollection)
{
    // Arrange: populate with a known count.
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u);

    // Act: erase the full range [begin, end) removes every element.
    collection->erase(collection->begin(), collection->end());

    // Assert: vector is empty afterward.
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
    // Arrange: start with some elements.
    add_entries(5);

    const auto sizeBeforeReserve = collection->size();
    const auto capacityBeforeReserve = collection->capacity();

    // Act: reserve requests more storage without changing the number of elements.
    // We reserve more than current capacity to make the expected outcome predictable.
    const auto requestedCapacity = capacityBeforeReserve + 50;
    collection->reserve(requestedCapacity);

    // Assert: reserve should NOT change size.
    ASSERT_EQ(collection->size(), sizeBeforeReserve);

    // Assert: capacity should be at least what we requested.
    EXPECT_GE(collection->capacity(), requestedCapacity);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexIsOutOfBounds)
{
    // Arrange: add 3 items so valid indexes are 0, 1, 2.
    add_entries(3);
    ASSERT_EQ(collection->size(), 3u);

    // Act + Assert: index == size is always out of bounds, so at() must throw.
    EXPECT_THROW(collection->at(collection->size()), std::out_of_range);
}


// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// Custom positive: verify push_back preserves order and values
TEST_F(CollectionTest, CustomPushBackPreservesOrderAndValues)
{
    // Arrange: a brand new vector should start empty.
    ASSERT_TRUE(collection->empty());

    // Act: push values in a specific order.
    const int firstValue = 10;
    const int secondValue = 20;
    const int thirdValue = 30;

    collection->push_back(firstValue);
    collection->push_back(secondValue);
    collection->push_back(thirdValue);

    // Assert: size should match the number of inserted values.
    ASSERT_EQ(collection->size(), 3u);

    // Assert: values should be in the same order they were inserted.
    EXPECT_EQ(collection->at(0), firstValue);
    EXPECT_EQ(collection->at(1), secondValue);
    EXPECT_EQ(collection->at(2), thirdValue);
}

// Custom negative: verify at() throws when using a huge invalid index
TEST_F(CollectionTest, CustomAtWithHugeIndexThrowsOutOfRange)
{
    // Arrange: add at least one element so the vector is not empty.
    add_entries(1);
    ASSERT_EQ(collection->size(), 1u);

    // Act + Assert: use a clearly invalid index.
    // size_t(-1) becomes the largest possible size_t value, which must be out of bounds.
    const std::size_t invalidIndex = static_cast<std::size_t>(-1);

    EXPECT_THROW(collection->at(invalidIndex), std::out_of_range);
}