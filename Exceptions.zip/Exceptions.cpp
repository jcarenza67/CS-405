// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>  // Added: for std::runtime_error, std::invalid_argument, std::exception

// Had to create because we need a custom exception type that's derived from std::exception
class CustomApplicationException : public std::runtime_error
{
public:
    // explicit avoids weird implicit conversions from const char*
    explicit CustomApplicationException(const char* message)
        : std::runtime_error(message) {}  // Store message so what() returns it
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    // Simulate a failure inside deeper app logic.
    throw std::runtime_error("Standard exception from do_even_more_custom_application_logic().");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    // We expect the call below might throw, so we handle it here and keep going.
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex)
    {
        // Print the message from the exception and move on.
        std::cout << "Caught std::exception in do_custom_application_logic(): " << ex.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
  
    // This is a required custom exception caset.
    throw CustomApplicationException("Custom exception from do_custom_application_logic().");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
     // Division by 0 is a real input error. We block it and throw a standard exception.
    if (den == 0.0f)
    {
        throw std::invalid_argument("Divide by zero.");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex) // Only catching what divide() throws
    {
        std::cout << "Caught divide() exception in do_division(): " << ex.what() << std::endl;
    }

}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomApplicationException& ex)
    {
        std::cout << "Caught CustomApplicationException in main(): " << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cout << "Caught std::exception in main(): " << ex.what() << std::endl;
    }
    catch (...)
    {
        std::cout << "Caught unknown exception in main()." << std::endl;
    }


    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu