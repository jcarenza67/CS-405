// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>
#include <string>

using namespace std; // ADDED: So I don't have to type std:: everywhere

int main()
{
  cout << "Buffer Overflow Example By Joseph Wilfong" << endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const string account_number = "CharlieBrown42";
  char user_input[20];

  cout << "Enter a value: ";

  // CHANGED: getline lets us tell C++ the max size of the buffer.
  // It will only store up to 19 characters here (and keeps room for '\0').
  cin.getline(user_input, sizeof(user_input));

  // CHANGED: If the user typed more than the buffer can hold, the stream sets fail().
  // That means we caught an "input too long" situation before it can mess with memory.
  if (cin.fail())
  {
      cout << "\nThat was too long. Please enter no more than "
          << (sizeof(user_input) - 1) << " characters.\n";

      // CHANGED: When getline fails, there are still extra characters sitting in the input stream.
      // Clear the error and throw away the rest of the line so the program stays in a good state.
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');

      // The important part: the account number never changes.
      cout << "Account Number = " << account_number << endl;
      return 1;
  }

  cout << "You entered: " << user_input << endl;
  cout << "Account Number = " << account_number << endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
